package com.sky.org;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkyServer1Application {

	public static void main(String[] args) {
		SpringApplication.run(SkyServer1Application.class, args);
	}
}

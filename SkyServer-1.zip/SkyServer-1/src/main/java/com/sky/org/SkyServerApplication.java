package com.sky.org;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkyServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkyServerApplication.class, args);
	}
}

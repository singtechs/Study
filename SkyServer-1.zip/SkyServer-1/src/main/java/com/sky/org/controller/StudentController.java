package com.sky.org.controller;

import java.net.HttpURLConnection;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

@RestController
public class StudentController {	
	
	@GetMapping("/hai")
		public String hai() {
		
		System.out.println("Testing ");
		
		final String uri = "http://partners.api.skyscanner.net/apiservices/pricing/v1.0";		 
	    RestTemplate restTemplate = new RestTemplate();
	    //String result = restTemplate.getForObject(uri, String.class);
	    // create request body
/*	    JSONObject request = new JSONObject();
	    request.put("cabinclass", "Economy");
	    request.put("country", "UK");
	    request.put("currency", "GBP");
	    request.put("locale", "en-GB");
	    request.put("locationSchema", "iata");
	    request.put("originplace", "EDI");
	    request.put("destinationplace", "LHR");
	    request.put("outbounddate", "2018-11-18");
	    request.put("inbounddate", "2018-11-22");
	    request.put("adults", "1");
	    request.put("children", "0");
	    request.put("infants", "0");
	    request.put("apikey", "ss630745725358065467897349852985");*/

	    // set headers
	    HttpHeaders headers = new HttpHeaders();
	    //headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		    
	    //Payment payment = new Payment("Aa4bhs");
	    MultiValueMap<String, Object> map = new LinkedMultiValueMap<String, Object>();
	    // map.add("payment", payment);
	    map.add("cabinclass", "Economy");
	    map.add("country", "UK");
	    map.add("currency", "GBP");
	    map.add("locale", "en-GB");
	    map.add("locationSchema", "iata");
	    map.add("originplace", "EDI");
	    map.add("destinationplace", "LHR");
	    map.add("outbounddate", "2018-11-18");
	    map.add("inbounddate", "2018-11-22");
	    map.add("adults", "1");
	    map.add("children", "0");
	    map.add("infants", "0");
	    map.add("apikey", "ss630745725358065467897349852985");
	    
	    HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<MultiValueMap<String, Object>>(map, headers);
	    //String result = restTemplate.postForObject(uri, httpEntity, String.class);	    
	    //HttpEntity<String> response = restTemplate.postForObject(uri, httpEntity, String.class);
	    //Payment res = restTemplate.postForObject(uri, httpEntity, Payment.class);	    
	    
	    HttpEntity<String> response = restTemplate.exchange(uri, HttpMethod.POST, httpEntity, String.class);
	    String result= response.getBody();
	    HttpHeaders resHeaders = response.getHeaders();	    
	    System.out.println("Location - " + response.getHeaders().getLocation());
		    	
		   // JSONArray children = new JSONObject(response.getHeaders()).getJSONObject("data").getJSONArray("children");
	        //if (children.length() > 0)
	        //    inconsistenciesCounter++;
	      //  Thread.sleep(2000);
	   
	    String url = String.format(response.getHeaders().getLocation().toString()+"?apikey=ss630745725358065467897349852985");
	    String res = restTemplate.getForObject(url, String.class);
	   // HttpEntity<String> response = restTemplate.getForObject(url, String.class);
	    
	   // Map<String, Object> params = new HashMap<>();
	   // params.put("apikey", "ss630745725358065467897349852985");
	  //  String res = restTemplate.getForObject(response.getHeaders().getLocation().toString(), String.class, params);
	    
	    System.out.println(res);
	    System.out.println(result);
	    System.out.println(resHeaders);

		return res;
	}

	
}

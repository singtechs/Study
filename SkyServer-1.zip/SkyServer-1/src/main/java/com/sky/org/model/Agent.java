package com.sky.org.model;

public class Agent {

}

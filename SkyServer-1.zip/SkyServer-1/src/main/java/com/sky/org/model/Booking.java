package com.sky.org.model;


public class Booking {

	private String cabinclass;
	private String country;
	private String currency;
	private String locale;
	private String locationSchema;
	private String originplace;
	private String destinationplace;
	private String outbounddate;
	private String inbounddate;
	private String adults;
	private String children;
	private String infants;
	    
	public Booking() {
	}

	public Booking(String cabinclass, String country, String currency, String locale, String locationSchema,
			String originplace,String destinationplace, String outbounddate,String inbounddate, 
			String adults, String children,String infants) {
		this.cabinclass = cabinclass;
		this.country = country;
		this.currency = currency;
		this.locale = locale;
		this.locationSchema = locationSchema;
		this.originplace = originplace;
		this.destinationplace = destinationplace;
		this.outbounddate = outbounddate;
		this.inbounddate = inbounddate;
		this.adults = adults;
		this.children = children;
		this.infants = infants;
	}

	public String getCabinclass() {
		return cabinclass;
	}

	public void setCabinclass(String cabinclass) {
		this.cabinclass = cabinclass;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public String getLocationSchema() {
		return locationSchema;
	}

	public void setLocationSchema(String locationSchema) {
		this.locationSchema = locationSchema;
	}

	public String getOriginplace() {
		return originplace;
	}

	public void setOriginplace(String originplace) {
		this.originplace = originplace;
	}

	public String getDestinationplace() {
		return destinationplace;
	}

	public void setDestinationplace(String destinationplace) {
		this.destinationplace = destinationplace;
	}

	public String getOutbounddate() {
		return outbounddate;
	}

	public void setOutbounddate(String outbounddate) {
		this.outbounddate = outbounddate;
	}

	public String getInbounddate() {
		return inbounddate;
	}

	public void setInbounddate(String inbounddate) {
		this.inbounddate = inbounddate;
	}

	public String getAdults() {
		return adults;
	}

	public void setAdults(String adults) {
		this.adults = adults;
	}

	public String getChildren() {
		return children;
	}

	public void setChildren(String children) {
		this.children = children;
	}

	public String getInfants() {
		return infants;
	}

	public void setInfants(String infants) {
		this.infants = infants;
	}
	
	
	
	
}

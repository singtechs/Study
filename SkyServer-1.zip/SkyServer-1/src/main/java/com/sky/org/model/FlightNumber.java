package com.sky.org.model;

public class FlightNumber {
	
	
	private String flightNumber;
	private Integer carrierId;
	
	public String getFlightNumber() {
	return flightNumber;
	}
	
	public void setFlightNumber(String flightNumber) {
	this.flightNumber = flightNumber;
	}
	
	public Integer getCarrierId() {
	return carrierId;
	}
	
	public void setCarrierId(Integer carrierId) {
	this.carrierId = carrierId;
	}

}

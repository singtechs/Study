package com.sky.org.model;

import java.util.List;

//import com.fasterxml.jackson.annotation.JsonProperty;

public class LivePrice {

	
	//private String sessionKey;
	private SessionKey sessionKey;
	
	private Query query;
	
	private String status;
	
	private List<Itinerary> itineraries = null;
	
	private List<Leg> legs = null;
	
	private List<Segment> segments = null;
	
	private List<Carrier> carriers = null;
	
	private List<Agent> agents = null;
	
	private List<Place> places = null;
	
	private List<Currency> currencies = null;
	
	private ServiceQuery serviceQuery;
	
	/*
	public String getSessionKey() {
	return sessionKey;
	}
	
	
	public void setSessionKey(String sessionKey) {
	this.sessionKey = sessionKey;
	} */	
	
	
	public Query getQuery() {
	return query;
	}
	
	
	public SessionKey getSessionKey() {
		return sessionKey;
	}


	public void setSessionKey(SessionKey sessionKey) {
		this.sessionKey = sessionKey;
	}


	public void setQuery(Query query) {
	this.query = query;
	}
	
	
	public String getStatus() {
	return status;
	}
	
	
	public void setStatus(String status) {
	this.status = status;
	}
	
	
	public List<Itinerary> getItineraries() {
	return itineraries;
	}
	
	
	public void setItineraries(List<Itinerary> itineraries) {
	this.itineraries = itineraries;
	}
	
	
	public List<Leg> getLegs() {
	return legs;
	}
	
	
	public void setLegs(List<Leg> legs) {
	this.legs = legs;
	}
	
	
	public List<Segment> getSegments() {
	return segments;
	}
	
	
	public void setSegments(List<Segment> segments) {
	this.segments = segments;
	}
	
	
	public List<Carrier> getCarriers() {
	return carriers;
	}
	
	
	public void setCarriers(List<Carrier> carriers) {
	this.carriers = carriers;
	}
	
	
	public List<Agent> getAgents() {
	return agents;
	}
	
	
	public void setAgents(List<Agent> agents) {
	this.agents = agents;
	}
	
	
	public List<Place> getPlaces() {
	return places;
	}
	
	
	public void setPlaces(List<Place> places) {
	this.places = places;
	}
	
	
	public List<Currency> getCurrencies() {
	return currencies;
	}
	
	
	public void setCurrencies(List<Currency> currencies) {
	this.currencies = currencies;
	}
	
	
	public ServiceQuery getServiceQuery() {
	return serviceQuery;
	}
	
	
	public void setServiceQuery(ServiceQuery serviceQuery) {
	this.serviceQuery = serviceQuery;
	}
}

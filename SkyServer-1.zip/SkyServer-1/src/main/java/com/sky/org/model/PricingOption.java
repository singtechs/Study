package com.sky.org.model;

import java.util.List;

public class PricingOption {
		
	
	private List<Integer> agents = null;
	private Integer quoteAgeInMinutes;
	private Float price;
	private String deeplinkUrl;
	
	
	public List<Integer> getAgents() {
	return agents;
	}
	
	
	public void setAgents(List<Integer> agents) {
	this.agents = agents;
	}
	
	
	public Integer getQuoteAgeInMinutes() {
	return quoteAgeInMinutes;
	}
	
	
	public void setQuoteAgeInMinutes(Integer quoteAgeInMinutes) {
	this.quoteAgeInMinutes = quoteAgeInMinutes;
	}
	
	
	public Float getPrice() {
	return price;
	}
	
	
	public void setPrice(Float price) {
	this.price = price;
	}
	
	
	public String getDeeplinkUrl() {
	return deeplinkUrl;
	}
	
	
	public void setDeeplinkUrl(String deeplinkUrl) {
	this.deeplinkUrl = deeplinkUrl;
	}

}

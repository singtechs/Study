package com.sky.org.model;

public class Query {

	
	private String country;
	
	private String currency;
	
	private String locale;
	
	private Integer adults;
	
	private Integer children;
	
	private Integer infants;
	
	private String originPlace;
	
	private String destinationPlace;
	
	private String outboundDate;
	
	private String inboundDate;
	
	private String locationSchema;
	
	private String cabinClass;
	
	private Boolean groupPricing;
	
	
	public String getCountry() {
	return country;
	}
	
	
	public void setCountry(String country) {
	this.country = country;
	}
	
	
	public String getCurrency() {
	return currency;
	}
	
	
	public void setCurrency(String currency) {
	this.currency = currency;
	}
	
	
	public String getLocale() {
	return locale;
	}
	
	
	public void setLocale(String locale) {
	this.locale = locale;
	}
	
	
	public Integer getAdults() {
	return adults;
	}
	
	
	public void setAdults(Integer adults) {
	this.adults = adults;
	}
	
	
	public Integer getChildren() {
	return children;
	}
	
	
	public void setChildren(Integer children) {
	this.children = children;
	}
	
	
	public Integer getInfants() {
	return infants;
	}
	
	
	public void setInfants(Integer infants) {
	this.infants = infants;
	}
	
	
	public String getOriginPlace() {
	return originPlace;
	}
	
	
	public void setOriginPlace(String originPlace) {
	this.originPlace = originPlace;
	}
	
	
	public String getDestinationPlace() {
	return destinationPlace;
	}
	
	
	public void setDestinationPlace(String destinationPlace) {
	this.destinationPlace = destinationPlace;
	}
	
	
	public String getOutboundDate() {
	return outboundDate;
	}
	
	
	public void setOutboundDate(String outboundDate) {
	this.outboundDate = outboundDate;
	}
	
	
	public String getInboundDate() {
	return inboundDate;
	}
	
	
	public void setInboundDate(String inboundDate) {
	this.inboundDate = inboundDate;
	}
	
	
	public String getLocationSchema() {
	return locationSchema;
	}
	
	
	public void setLocationSchema(String locationSchema) {
	this.locationSchema = locationSchema;
	}
	
	
	public String getCabinClass() {
	return cabinClass;
	}
	
	
	public void setCabinClass(String cabinClass) {
	this.cabinClass = cabinClass;
	}
	
	
	public Boolean getGroupPricing() {
	return groupPricing;
	}
	
	
	public void setGroupPricing(Boolean groupPricing) {
	this.groupPricing = groupPricing;
	}
}

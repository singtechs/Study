package com.sky.org.model;

//import com.fasterxml.jackson.annotation.JsonProperty;

public class ServiceQuery {
	


private String dateTime;


public String getDateTime() {
return dateTime;
}


public void setDateTime(String dateTime) {
this.dateTime = dateTime;
}

}
